﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Data.Common;

namespace Dataaccess
{
    public class SqlClass
    {
        public DataSet Getcustomer()
        {
            string Connectionstring = @"Data Source=WINSG185310-74Z\SQLEXPRESS;Initial Catalog=mycustdb;Integrated Security=True";
            SqlConnection objConnection = new SqlConnection(Connectionstring);
            objConnection.Open();
            SqlCommand objcommand = new SqlCommand("SELECT  *  FROM Customer1 ", objConnection);
            DataSet objdataset = new DataSet();
            SqlDataAdapter objdataadapter = new SqlDataAdapter(objcommand);
            //objdataadapter.SelectCommand = objcommand;
            objdataadapter.Fill(objdataset);
            objConnection.Close();
            return objdataset;
        }

        public DataSet Getcustomer(string customercode)
        {
            string Connectionstring = @"Data Source=WINSG185310-74Z\SQLEXPRESS;Initial Catalog=mycustdb;Integrated Security=True";
            SqlConnection objConnection = new SqlConnection(Connectionstring);
            objConnection.Open();
            SqlCommand objcommand = new SqlCommand("SELECT * FROM Customer1 WHERE customername= '" + customercode + "' ", objConnection);
            DataSet objdataset = new DataSet();
            SqlDataAdapter objdataadapter = new SqlDataAdapter(objcommand);
            //objdataadapter.SelectCommand = objcommand;
            objdataadapter.Fill(objdataset);
            objConnection.Close();
            return objdataset;
        }
        public bool Insertcustomer(string strcustomername, string strcountry, string gender, string hobbies1, string status)
        {
            
                string Connectionstring = @"Data Source=WINSG185310-74Z\SQLEXPRESS;Initial Catalog=mycustdb;Integrated Security=True";
                SqlConnection objConnection = new SqlConnection(Connectionstring);
                objConnection.Open();
            try
            {

            
                string strInsertCommand = "INSERT INTO Customer1 VALUES('"
                                        + strcustomername + "','"
                                        + strcountry + "','"
                                        + gender + "','"
                                        + hobbies1 + "',"
                                        + status + ")";
                SqlCommand objCommand = new SqlCommand(strInsertCommand, objConnection);


                objCommand.ExecuteNonQuery();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                objConnection.Close();
            }
        }

        public bool Updatecustomer(string strcustomername, string strcountry, string gender, string hobbies1, string status)
        {
            string Connectionstring = @"Data Source=WINSG185310-74Z\SQLEXPRESS;Initial Catalog=mycustdb;Integrated Security=True";
            SqlConnection objConnection = new SqlConnection(Connectionstring);
            objConnection.Open();
            string strupdateCommand = "UPDATE Customer1 SET customername='"
                                    + strcustomername + "',country='"
                                    + strcountry + "',gender='"
                                    + gender + "',hobbies='"
                                    + hobbies1 + "',married="
                                    + status + "WHERE customername= '" + strcustomername + "'";

            SqlCommand objCommand = new SqlCommand(strupdateCommand, objConnection);
            objCommand.ExecuteNonQuery();
            objConnection.Close();
            return true;




        }
        public bool Deletecustomer(string strcustomername)
        {

            string Connectionstring = @"Data Source=WINSG185310-74Z\SQLEXPRESS;Initial Catalog=mycustdb;Integrated Security=True";
            SqlConnection objConnection = new SqlConnection(Connectionstring);
            objConnection.Open();
            SqlCommand objcommand = new SqlCommand("DELETE FROM Customer1 WHERE customername= '" + strcustomername + "' ", objConnection);

            objcommand.ExecuteNonQuery();
            objConnection.Close();
            return true;
        }




        }
    }


 
