﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Data;
using System.Data.SqlClient;

namespace customerweb
{
    public partial class userval : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            if (Isvalid())
            {
                FormsAuthentication.RedirectFromLoginPage(txtusername.Text, true);
            }
            
        }

        public DataSet Getuser(string strusername, string strpassword)
        {
            string Connectionstring = @"Data Source=WINSG185310-74Z\SQLEXPRESS;Initial Catalog=mycustdb;Integrated Security=True";
            SqlConnection objConnection = new SqlConnection(Connectionstring);
            objConnection.Open();
            SqlCommand objcommand = new SqlCommand("SELECT  *  FROM users WHERE username='" + strusername + "' and password='" + strpassword + "'  ", objConnection);
            DataSet objdataset = new DataSet();
            SqlDataAdapter objdataadapter = new SqlDataAdapter(objcommand);
            //objdataadapter.SelectCommand = objcommand;
            objdataadapter.Fill(objdataset);
            objConnection.Close();
            return objdataset;
        }

        public bool Isvalid()
        {
            DataSet obj = Getuser(txtusername.Text, txtpassword.Text);
            if (obj.Tables[0].Rows.Count == 0)
            {
                return false;
            }
            else
                return true;
        }
    }
}