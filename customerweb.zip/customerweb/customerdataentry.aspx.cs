﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Dataaccess;
using System.Data.SqlClient;
using System.Data;

namespace customerweb
{
    public partial class customerdataentry : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            Loadcustomer();

        }
        private void Loadcustomer()
        {
            SqlClass sqlobj = new SqlClass();
            datagridweb.DataSource=sqlobj.Getcustomer();
            datagridweb.DataBind();
        }

        protected void btnadd_Click(object sender, EventArgs e)
        {




            //customerpreview obj = new customerpreview();
            string hobbies1, status, gender;
            string strcustomername = txtcustomername.Text;
            string strcountry = ddlcountry.Text;
            if (RadioButton1.Checked)
            {
                gender = "male";

            }
            else
            {
                gender = "female";
            }
            if (CheckBox2.Checked && CheckBox1.Checked)
            {
                hobbies1 = "reading" + "painting";
            }
            else
            if (CheckBox1.Checked)
            {
                hobbies1 = "painting";
            }
            else
            if (CheckBox2.Checked)
            {
                hobbies1 = "reading";
            }
            else
            {
                hobbies1 = "none";
            }
            if (RadioButton3.Checked)
            {
                status = "1";
            }
            else
            {
                status = "0";
            }
            SqlClass sqlinsert = new SqlClass();
            sqlinsert.Insertcustomer(txtcustomername.Text, ddlcountry.Text, gender, hobbies1, status);
            Loadcustomer();
        }
        /*private void displaycustomer(string customercode)
        {
            SqlClass objsql = new SqlClass();
            DataSet objdataset = objsql.Getcustomer(customercode);
            String strcustomername = objdataset.Tables[0].Rows[0][0].ToString();
            String strcountryname = objdataset.Tables[0].Rows[0][1].ToString();
            String strgender = objdataset.Tables[0].Rows[0][2].ToString();
            String strhobbies = objdataset.Tables[0].Rows[0][3].ToString();
            bool married = Convert.ToBoolean(objdataset.Tables[0].Rows[0][4]);
            txtcustomername.Text = strcustomername;
            ddlcountry.Text = strcountryname;
            if (strgender == "male")
            {
                RadioButton1.Checked = true;
            }
            else
            {
                RadioButton2.Checked = true;
            }
            if (married == true)
            {
                RadioButton3.Checked = true;
            }
            else
            {
                RadioButton4.Checked = true;
            }
            if (strhobbies == "reading")
            {
                CheckBox1.Checked = true;
            }
            else
            {
                CheckBox2.Checked = true;
            }
        }*/

        //protected void datagridweb_SelectedIndexChanged1(object sender, EventArgs e)
        //{
            //string strcustomername = datagridweb.Rows[datagridweb.SelectedIndex].Cells[1].Text;
            //displaycustomer(strcustomername);
        //}

        protected void btnupdate_Click(object sender, EventArgs e)
        {

            //customerpreview obj = new customerpreview();
            string hobbies1, status, gender;
            if (RadioButton1.Checked)
            {
                gender = "male";

            }
            else
            {
                gender = "female";
            }
            if (CheckBox2.Checked && CheckBox1.Checked)
            {
                hobbies1 = "reading" + "painting";

            }
            else
            if (CheckBox1.Checked)
            {
                hobbies1 = "painting";
            }
            else
            if (CheckBox2.Checked)
            {
                hobbies1 = "reading";
            }
            else
            {
                hobbies1 = "none";
            }
            if (RadioButton3.Checked)
            {
                status = "1";

            }
            else
            {
                status = "0";
            }
            SqlClass sqlinsert = new SqlClass();
            sqlinsert.Updatecustomer(txtcustomername.Text, ddlcountry.Text, gender, hobbies1, status);
            Loadcustomer();



        }

        protected void btndelete_Click(object sender, EventArgs e)
        {
            SqlClass sqlinsert = new SqlClass();
            sqlinsert.Deletecustomer(txtcustomername.Text);
            Loadcustomer();
        }

       
    }

}